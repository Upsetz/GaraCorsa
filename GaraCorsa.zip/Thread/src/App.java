public class App {
    public static void main(String[] args) throws Exception {

        Thread c1 = new Thread(new Corridore("Samu"));
        Thread c2 = new Thread(new Corridore("Gabri"));
        Thread c3 = new Thread(new Corridore("Andrea"));
        Thread c4 = new Thread(new Corridore("Rida"));

        c1.start();
        c2.start();
        c3.start();
        c4.start();

        //Thread.sleep(5000);

        c1.join();
        c2.join();
        c3.join();
        c4.join();

        System.out.println("gara finita");

    }
}
